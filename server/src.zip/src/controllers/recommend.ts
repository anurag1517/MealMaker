import {Request,Response} from"express"
import {z} from"zod"
import {detectSeason} from"../utils/season"
import {recommend} from"../utils/recommender"

const BodySchema=z.object({
  pref:z.enum(["veg","nonveg"]),
  issues:z.array(z.string()).default([]),
  location:z.string(),
  mealType:z.enum(["breakfast","lunch","snacks","dinner"])
})

export async function handleRecommend(req:Request,res:Response){
  const parse=BodySchema.safeParse(req.body)
  if(!parse.success)return res.status(400).json({error:parse.error.issues})

  const b=parse.data
  const [latStr]=b.location.split(",")
  const lat=parseFloat(latStr)||0
  const season=detectSeason(lat,new Date().getMonth())
  try{
    const foods=await recommend(b,season)
    res.json({season,foods})
  }catch(err){
    console.error(err)
    res.status(500).json({error:"server"})
  }
}
