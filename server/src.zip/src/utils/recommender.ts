import Food from"../models/Food"
import {ReqBody} from"../types"

export async function recommend(b:ReqBody,season:string){
  const q:any={
    veg:b.pref==="veg",
    mealTypes:b.mealType,
    seasons:season,
    regions:{$in:[b.location,"general"]},
    avoidFor:{$nin:b.issues}
  }
  if(b.issues.length)q.$or=[{goodFor:{$in:b.issues}},{goodFor:[]}]

  return Food.find(q).limit(6)  // returns promise
}
